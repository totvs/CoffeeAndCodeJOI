var http = require('http');
var nodeRed = require("node-red");
var express = require('express');
const fs = require('fs');

var ip = process.argv.splice(2, process.argv.length -1).join(' ')
console.log(ip);
  
http.createServer(function(req, resp) {
  var headers = req.headers;
  var method = req.method;
  var url = req.url;
  url = url.substring(2);

  var lista = url.split('&');

  var txt = "";
  console.log("method = " + method + " - url = " + url + " - " + lista[0]);
  
  //console.log("headers = " + headers);
  for(var i = 0; i < lista.length; i++) {
      //var it = ;
      var tmp = lista[i].split("=");
      var key = tmp[0];
      var value = tmp[1];
      if (value != "NaN") {
          txt += key + "," + value + "\n";
      }
  }
  fs.writeFile('/fndlm/sensorDHT.txt', txt, {enconding:'utf-8',flag: 'w'}, function (err) {
      if (err) throw err;
  });
  
  var body = [];
  req.on('error', function(err) {
    console.error(err);
  }).on('data', function(chunk) {
    body.push(chunk);
  }).on('end', function() {
    body = Buffer.concat(body).toString();
    // BEGINNING OF NEW STUFF

    resp.on('error', function(err) {
      console.error(err);
    });

    resp.statusCode = 200;
    resp.setHeader('Content-Type', 'text/html');
    // Note: the 2 lines above could be replaced with this next one:
    // response.writeHead(200, {'Content-Type': 'application/json'})

    var responseBody = {
      headers: headers,
      method: method,
      url: url,
      body: body
    };

    resp.write(JSON.stringify(responseBody));
	
    resp.end();
    // Note: the 2 lines above could be replaced with this next one:
    // response.end(JSON.stringify(responseBody))

    // END OF NEW STUFF
  });
}).listen(8181,ip);

console.log("Servidor na porta 8181. Acesse http://" + ip + ":8181.");
